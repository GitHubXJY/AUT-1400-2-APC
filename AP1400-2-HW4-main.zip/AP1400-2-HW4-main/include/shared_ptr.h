#ifndef SHARED_PTR
#define SHARED_PTR


#endif //SHARED_PTR