#ifndef Q1_H
#define Q1_H

#endif //Q1_H