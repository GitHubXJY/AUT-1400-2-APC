#ifndef Q2_H
#define Q2_H

#endif //Q2_H